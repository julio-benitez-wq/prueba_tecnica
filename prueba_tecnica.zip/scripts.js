const productosList = document.getElementById('productosList');
const totalSpan = document.getElementById('totalVenta');
const ventaForm = document.getElementById('ventaForm');
let productos = [];

fetch('api/productos.php')
    .then(res => res.json())
    .then(data => {
        productos = data;
        data.forEach(prod => {
            if (prod.estatus === 'disponible') {
                productosList.innerHTML += `
                    <div class="mb-2">
                        <label>${prod.nombre} ($${prod.precio})</label>
                        <input type="number" min="0" max="${prod.stock}" value="0"
                        class="form-control cantidad"
                        data-id="${prod.id}" data-precio="${prod.precio}">
                    </div>`;
            }
        });
    });

ventaForm.addEventListener('input', () => {
    let total = 0;
    document.querySelectorAll('.cantidad').forEach(input => {
        total += input.value * input.dataset.precio;
    });
    totalSpan.textContent = total.toFixed(2);
});

ventaForm.addEventListener('submit', e => {
    e.preventDefault();
    const items = [];
    document.querySelectorAll('.cantidad').forEach(input => {
        const cantidad = parseInt(input.value);
        if (cantidad > 0) {
            items.push({
                producto_id: input.dataset.id,
                cantidad
            });
        }
    });

    fetch('api/ventas.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            Swal.fire('¡Venta registrada con éxito!');
            location.reload();
        }
    });
});

fetch('api/ventas_listado.php')
    .then(res => res.json())
    .then(data => {
        const list = document.getElementById('historialVentas');
        data.forEach(v => {
            const li = document.createElement('li');
            li.className = 'list-group-item';
            li.innerText = `Venta #${v.id} - ${v.fecha} - $${v.total}`;
            list.appendChild(li);
        });
    });
