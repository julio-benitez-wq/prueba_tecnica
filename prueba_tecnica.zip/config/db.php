<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'prueba_tecnica';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
