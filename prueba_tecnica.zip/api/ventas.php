<?php
require '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $total = 0;

    foreach ($data['items'] as $item) {
        $id = $item['producto_id'];
        $cantidad = $item['cantidad'];

        $res = $conn->query("SELECT precio, stock FROM productos WHERE id = $id");
        $producto = $res->fetch_assoc();

        if ($producto['stock'] < $cantidad) {
            http_response_code(400);
            echo json_encode(["error" => "Stock insuficiente para el producto ID $id"]);
            exit;
        }

        $total += $producto['precio'] * $cantidad;
    }

    $conn->query("INSERT INTO ventas (total) VALUES ($total)");
    $venta_id = $conn->insert_id;

    foreach ($data['items'] as $item) {
        $id = $item['producto_id'];
        $cantidad = $item['cantidad'];

        $res = $conn->query("SELECT precio FROM productos WHERE id = $id");
        $precio = $res->fetch_assoc()['precio'];
        $subtotal = $precio * $cantidad;

        $conn->query("INSERT INTO detalle_ventas (venta_id, producto_id, cantidad, subtotal)
                      VALUES ($venta_id, $id, $cantidad, $subtotal)");
        $conn->query("UPDATE productos SET stock = stock - $cantidad WHERE id = $id");

        $res = $conn->query("SELECT stock FROM productos WHERE id = $id");
        $stock = $res->fetch_assoc()['stock'];
        $estatus = $stock > 0 ? 'disponible' : 'agotado';
        $conn->query("UPDATE productos SET estatus = '$estatus' WHERE id = $id");
    }

    echo json_encode(["success" => true, "venta_id" => $venta_id]);
}
?>
