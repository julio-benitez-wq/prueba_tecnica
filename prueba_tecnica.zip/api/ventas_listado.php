<?php
require '../config/db.php';
$res = $conn->query("SELECT * FROM ventas ORDER BY fecha DESC");
echo json_encode($res->fetch_all(MYSQLI_ASSOC));
?>
