<?php
require '../config/db.php';
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $res = $conn->query("SELECT * FROM productos");
        echo json_encode($res->fetch_all(MYSQLI_ASSOC));
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $estatus = $data['stock'] > 0 ? 'disponible' : 'agotado';
        $stmt = $conn->prepare("INSERT INTO productos (nombre, precio, stock, estatus) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sdis", $data['nombre'], $data['precio'], $data['stock'], $estatus);
        $stmt->execute();
        echo json_encode(["success" => true]);
        break;

    case 'PUT':
        $data = json_decode(file_get_contents("php://input"), true);
        $estatus = $data['stock'] > 0 ? 'disponible' : 'agotado';
        $stmt = $conn->prepare("UPDATE productos SET nombre=?, precio=?, stock=?, estatus=? WHERE id=?");
        $stmt->bind_param("sdssi", $data['nombre'], $data['precio'], $data['stock'], $estatus, $data['id']);
        $stmt->execute();
        echo json_encode(["success" => true]);
        break;

    case 'DELETE':
        parse_str(file_get_contents("php://input"), $_DELETE);
        $id = $_DELETE['id'];
        $conn->query("DELETE FROM productos WHERE id=$id");
        echo json_encode(["success" => true]);
        break;
}
?>
